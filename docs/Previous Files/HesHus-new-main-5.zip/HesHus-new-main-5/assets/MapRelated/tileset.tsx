<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tileset" tilewidth="32" tileheight="32" tilecount="216" columns="18">
 <image source="tileset.png" width="576" height="384"/>
</tileset>
