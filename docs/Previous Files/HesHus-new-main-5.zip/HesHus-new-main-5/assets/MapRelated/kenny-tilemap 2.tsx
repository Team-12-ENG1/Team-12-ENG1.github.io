<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="kenny-tilemap" tilewidth="16" tileheight="16" spacing="1" tilecount="486" columns="27">
 <image source="kenny-tilemap.png" trans="000000" width="458" height="305"/>
 <tile id="16">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="20">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="21">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="22">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="46">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="47">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="70">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="72">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="74">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="75">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="76">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="82">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="83">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="97">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="98">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="99">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="100">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="101">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="102">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="103">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="108">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="109">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="110">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="124">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="125">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="127">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="128">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="129">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="135">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="136">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="137">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="151">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="152">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="153">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="154">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="155">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="156">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="157">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="170">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="171">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="172">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="178">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="179">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="180">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="181">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="182">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="183">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="184">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="197">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="198">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="199">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="205">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="206">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="207">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="208">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="209">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="210">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="211">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="224">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="225">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="226">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="270">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="271">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="272">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="297">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="298">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="299">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="327">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="339">
  <properties>
   <property name="collision" value=""/>
   <property name="interactable" value=""/>
  </properties>
 </tile>
 <tile id="354">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="355">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="356">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="357">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="366">
  <properties>
   <property name="collision" value=""/>
   <property name="interactable" value=""/>
  </properties>
 </tile>
 <tile id="381">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="447">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="448">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="474">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
 <tile id="475">
  <properties>
   <property name="collision" value=""/>
  </properties>
 </tile>
</tileset>
